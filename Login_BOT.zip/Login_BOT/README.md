# Login_BOT
Um BOT que consegue logar sites.

0.1:\
    -Loga somente com chrome.\
    -Nome do arquivo .txt não pode ser alterado.\
